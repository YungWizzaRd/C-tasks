/*

Name: ALeksejs Gerasimovs
St. apl. numurs: ag21275

D1. Izveidot klasi "Komplekss skaitlis", kurā tiek glabāti divi skaitļi,
kas nosaka kompleksu skaitli. Klasei izveidot šādas metodes:
(1) konstruktors, ar kuru tiek padotas sākotnējās vērtības,
(2) destruktors, kurš paziņo par objekta likvidēšanu,
(3) metode "Pieskaitīt" ar diviem parametriem,
kas (savam) kompleksajam skaitlim pieskaita otru (kas padots ar parametriem) kompleksu skaitli un rezultātu noglabā pie sevis,
(4) metode "Reizināt" – ar diviem parametriem, kas sareizina kompleksus skaitļus, (5) metode "Drukāt", kas izdrukā komplekso skaitli.
*/


#include<iostream>
#include"KompleksaSkaitlis.h"

using namespace std;


int main() {
	int ok = 1;
	do{
		double A, B, C, D;
		string operacija;
		cout << "Input operation name (add or multiply): " << endl;
		cin >> operacija;
		if (operacija == "add" || operacija == "multiply") {


			cout << "Input first number: A+B*I: " << endl;
			cin >> A;
			cin >> B;
			KompleksaSkaitlis x(A, B);

			cout << "Input second number C+D*I:" << endl;
			cin >> C;
			cin >> D;

			if (operacija == "add") {
				x.pieskaitit(C, D);
			}
			else if (operacija == "multiply") {
				x.reizinat(C, D);
			}
			x.drukat();
		}
		else {

			cout << "Operation name wrote incorrect!" << endl;

		}
			cout << "Input (1) to continue or (0) to finish.";
			cin >> ok;

	} while (ok == 1);

}

/*							TEST
*	 Method		Numbers					Expected result		Result
*
*	 add	    1 3  5 7				 (6)+(10)*i			   +
*	multiply	1 3  5 7			 	 (-16)+(22)*i	       +
*
*
*/
