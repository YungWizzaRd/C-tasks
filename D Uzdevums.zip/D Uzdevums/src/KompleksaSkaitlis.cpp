#include"KompleksaSkaitlis.h"

using namespace std;


KompleksaSkaitlis::KompleksaSkaitlis(double a, double b) { //izveido objektu

	A = a;
	B = b;

}
KompleksaSkaitlis::~KompleksaSkaitlis() { //Iznīcina objelktu
	cout << "Object delete!"<<endl;
}
void KompleksaSkaitlis::pieskaitit(double c, double d) {//C+D*I pieskaitīšana

	A += c;
	B += d;

}
void KompleksaSkaitlis::reizinat(double c, double d) {//C+D*I reizināšana
	double a = A;
	double b = B;


	A = a * c - b * d;
	B= b * c + a * d;

}
void KompleksaSkaitlis::drukat(){ //Kompleksa skaitļa drukāšana

	cout<< "("<<A<<")+("<<B<<")* i" << endl;

}
