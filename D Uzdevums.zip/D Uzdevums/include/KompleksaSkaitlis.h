#ifndef KompleksaSkaitlis_h
#define KompleksaSkaitlis_h

class KompleksaSkaitlis
{
public:
	KompleksaSkaitlis(double a, double b);
	~KompleksaSkaitlis();
	void pieskaitit(double c, double d);
	void reizinat(double c, double d);
	void drukat();

private:
	double A;
	double B;
};

#endif
