/*******************************************
Aleksejs Gerasimovs ag21275

Izveidot divas programmas valodā C++, kas strādā ar vērtību virkni divos dažādos veidos :
1) to realizējot kā vienvirziena saistīto sarakstu, izmantojot dinamiskas datu struktūras,
2) izmantojot STL::list konteineru.
Abās realizācijās ir jāizveido prasītā specifiskā vērtību virknes apstrādes funkcija un jānodemonstrē tā darbībā,
cita starpā parādot gan sākotnējās, gan rezultējošās vērtības.
Abās programmās :
a) jābūt iespējai ievadīt saraksta elementus(izveidot patvaļīgu sarakstu),
b) jāpielieto uzrakstītā funkcija sarakstam,
c) jāizdrukā saraksts pēc funkcijas darbības.
d) beigās jāiznīcina saraksts - korekti jāatbrīvo izdalītā atmiņa(lietojot delete vai clear).
Sīkākas prasības sk.Laboratorijas darbu noteikumos.

G12.Uzrakstīt funkciju, kas pārvieto saraksta n - to elementu uz saraksta beigām.Darbība jāveic, pārkabinot saites, nevis pārrakstot elementu vērtības.

* *******************************************/

#include <iostream>
#include <string.h>
#include "../G12/G12.h"
using namespace std;

void test1() // Tests1: n indekss ir lielāks par saraksta garumu
{
    cout << "test1: ";
    node *head = NULL;

    append(&head, 1);
    append(&head, 2);
    append(&head, 3);

    try
    {
        moven(head, 4);
    }
    catch (const char *e)
    {
        cout << (strcmp(e, "n out of list bounds") == 0) << endl;
    }
    catch(...)
    {
        cout << "Cita kļūda" << endl;
    }
    deleteList(&head);

}
void test2() // Tests2: tukšs saraksts
{
    cout << "test2: ";
    node *head = NULL;

    try
    {
        moven(head, 1);
    }
    catch (const char *e)
    {
        cout << (strcmp(e, "empty list") == 0) << endl;
    }
    catch(...)
    {
        cout << "Cita kļūda" << endl;
    }
    deleteList(&head);
}

void test3() // Tests3: viss ir korekti
{
    cout << "test3: ";
    node *head = NULL;
    append(&head, 1);
    append(&head, 2);
    append(&head, 3);
    append(&head, 4);
    append(&head, 5);

    moven(head, 3);

    // 1 2 3 5 4
    cout << (listlength(head) == 5 && head->num == 1 && head->next->num == 2 && head->next->next->num == 3 && head->next->next->next->num == 5 && head->next->next->next->next->num == 4) << endl;

    deleteList(&head);
}

int main ()
{
    test1();
    test2();
    test3();
}
