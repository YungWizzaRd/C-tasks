struct node
{
    int num;
    struct node* next;
};

void push(struct node** head, int node_data);

void append(struct node** head, int node_data);

void printList(node* node);

void deleteList(struct node** head);

void moven(node*& head, int n);

void fillList(struct node** head);

int listlength(node *head);
