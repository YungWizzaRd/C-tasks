#include <iostream>
#include "G12.h"
using namespace std;

void push(struct node** head, int node_data)
{
    struct node* newNode = new node;
    newNode->num = node_data;
    newNode->next = (*head);
    (*head) = newNode;
}

void append(struct node** head, int node_data)
{
    struct node* newNode = new node;
    struct node* last = *head;
    newNode->num = node_data;
    newNode->next = NULL;
    if (*head == NULL)
    {
        *head = newNode;
        return;
    }
    while (last->next != NULL)
    {
        last = last->next;
    }
    last->next = newNode;
    return;
}

void printList(node* node)
{
    while (node != NULL)
    {
        cout << node->num << " ";
        node = node->next;
    }
    cout << endl;
}

void deleteList(struct node** head)
{
    node* current = *head;
    node* next = NULL;

    while (current != NULL)
    {
        next = current->next;
        free(current);
        current = next;
    }

    *head = NULL;
}

void moven(node*& head, int n)
{
    if (head == NULL) throw "empty list";

    if (n > listlength(head)) throw "n out of list bounds";

    node* tmp = head;
    for (int i = 0; i < n && tmp->next; ++i)
    {
        tmp = tmp->next;
    }
    node* ttmp = head;
    if (tmp != head)
    {
        while (ttmp->next)
        {
            if (tmp == ttmp->next)
            {
                ttmp->next = tmp->next;
                break;
            }
            ttmp = ttmp->next;
        }
    }
    else {
        head = head->next;
    }
    ttmp = head;
    while (ttmp->next)
    {
        ttmp = ttmp->next;
    }
    ttmp->next = tmp;
    tmp->next = NULL;
}

void fillList(struct node** head)
{
    int input;
    cin >> input;
    while (input)
    {
        append(head, input);
        cin >> input;
    }
}

int listlength(node *head){
    node *temp;
    int counter=0;
    for (temp = head; temp!=NULL; temp=temp->next){counter++;};
    return counter;
}

